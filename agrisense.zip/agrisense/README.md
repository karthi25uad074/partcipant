# AgriSense — Hyper-Local Climate Intelligence & Precision Agriculture Decision Support Platform

AgriSense is a full-stack decision-support platform that fuses plot geometry, Sentinel-2-style spectral observations, IoT-style soil and weather telemetry, a downscaled weather forecast, soil parameters, cultivation history, and mandi prices into auditable plot advisories. It provides crop-health and risk views, yield and climate-risk predictions, irrigation and fertilizer plans, pest scouting guidance, multilingual low-bandwidth delivery, and fleet-level GIS intelligence while continuing to operate without Supabase credentials through a local fallback chain.

## Functional requirement coverage

| Functional requirement | Implementation in this project |
|---|---|
| Hyper-local field intelligence | Each plot carries a GeoJSON boundary, centroid, crop, variety, soil, irrigation method, and crop stage. The GIS API exposes those boundaries with plot-level health, yield, risk, and irrigation attributes. |
| Multimodal data integration | The feature service combines satellite indices, sensor telemetry, forecast weather, soil-library parameters, and cultivation history into the model feature vector. |
| Remote sensing and vegetation health | Raw blue/red/NIR/SWIR reflectance is transformed into NDVI, EVI, SAVI, NDWI, MSAVI, chlorophyll index, and LAI; plot dossiers return a satellite series and health decomposition. |
| Crop intelligence and early warning | The inference layer serves crop-yield regression, pest, disease, drought, flood, and climate-anomaly outputs, each with confidence and explanations. |
| Actionable agronomy | The advisory engine produces FAO-56 water-balance schedules, yield-goal NPK prescriptions, pest-condition assessments, crop-rotation guidance, harvest planning, and climate-adaptation actions. |
| GIS and decision dashboards | The React application includes fleet KPIs, district risk rollups, plot dossiers, a Leaflet map, plot polygons, and an NDVI management-zone grid. |
| Explainable AI | Each prediction exposes local ablation-to-median drivers and held-out-set permutation importance. |
| Local-language farmer communication | Advisory and SMS output support English, Tamil, Malayalam, and Hindi through offline pattern and glossary localisation. |
| Low-bandwidth and offline delivery | GZip responses, a compact offline bundle, SMS/IVR/USSD digest payloads, a SQLite snapshot mirror, and a queued-write mechanism support intermittent connectivity. |
| Farm automation and planning extensions | The API emits an irrigation valve command with rain, runtime, and soil-moisture interlocks; it also exposes a water-balance/NDVI digital twin, price outlook, and carbon estimate. |

## Technology stack

| Layer | Components used in the codebase |
|---|---|
| Frontend | React, TypeScript, Vite, Tailwind CSS, Leaflet/react-leaflet, Recharts, Lucide icons |
| API | FastAPI, Pydantic, Uvicorn, CORS middleware, GZip middleware |
| Analytics and ML | NumPy, scikit-learn gradient boosting, random forest, histogram gradient boosting, and IsolationForest |
| Data | Supabase/PostgreSQL schema, Supabase Python client, local SQLite mirror, deterministic in-process demo dataset |
| Operations | `python-dotenv`, JSON offline metadata, OpenAPI at `/docs` and `/redoc` |

## Repository layout

```text
agrisense/
├── backend/
│   ├── .env.example
│   ├── requirements.txt
│   ├── app/
│   │   ├── config.py          # configuration, crop/soil/pest libraries
│   │   ├── dataset.py         # deterministic demonstration data builders
│   │   ├── repository.py      # Supabase → SQLite → demo data access
│   │   ├── ml.py              # training corpus, models, explanations
│   │   ├── services.py        # features, agronomy, advisories, forecasts
│   │   ├── i18n.py            # offline localisation
│   │   ├── main.py            # FastAPI routes and middleware
│   │   └── seed.py            # Supabase seed command
│   └── data/                  # local SQLite mirror and offline metadata
├── frontend/
│   ├── src/
│   │   ├── App.tsx
│   │   ├── lib/api.ts
│   │   └── pages/             # overview, GIS, plot, advisory, model views
│   └── package.json
├── supabase/
│   └── schema.sql
└── docs/
    ├── ARCHITECTURE.md
    ├── API.md
    └── BENCHMARK.md
```

## Local setup

### Prerequisites

Install Python 3 and Node.js with npm. Supabase is optional for a local demo because the backend has a built-in fallback dataset.

### A. Run the backend

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --port 8000
```

The API is then available at `http://localhost:8000`; interactive OpenAPI documentation is at `http://localhost:8000/docs`.

### B. Run the frontend

In a second terminal:

```bash
cd frontend
npm install
VITE_API_BASE=http://localhost:8000 npm run dev
```

`VITE_API_BASE` is optional locally because the client defaults to `http://localhost:8000`. Set it when the frontend must call a different API origin:

```bash
VITE_API_BASE=https://your-api.example npm run dev
```

### C. Configure Supabase and load the demo dataset

1. Create a Supabase project.
2. Open its SQL Editor and run the complete contents of `supabase/schema.sql`.
3. In `backend/.env`, set `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`.
4. Seed the generated demonstration rows:

   ```bash
   cd backend
   source .venv/bin/activate
   python -m app.seed
   ```

The checked-in environment template also accepts `SUPABASE_ANON_KEY`, but the schema grants direct browser access only to `SELECT` rows. Use `SUPABASE_SERVICE_ROLE_KEY` for server-side writes.

## Data availability without Supabase

The repository always resolves data through three tiers:

1. **Supabase/PostgreSQL** when both `SUPABASE_URL` and a configured key are available and the `plots` table contains data. On a successful load, read tables are copied to the local mirror and pending writes are flushed.
2. **Local SQLite mirror** when Supabase is unavailable or unconfigured but a previous snapshot exists at `backend/data/agrisense_demo.db`. Advisory, prediction, and SMS writes are queued there for later replay.
3. **In-process deterministic demo dataset** when neither remote rows nor a local snapshot exists. `dataset.build_all()` generates reproducible farms, plots, telemetry, scenes, forecasts, history, and prices, then persists a local snapshot.

`backend/data/offline_cache.json` records the snapshot time and table counts; the SQLite database contains the stored row payloads. This means a no-credential local startup is supported by design.

## Troubleshooting

| Symptom | Check / resolution |
|---|---|
| Frontend reports a network error | Confirm the backend is running on port 8000, then use `curl -s http://localhost:8000/api/health`. If the frontend uses another origin, set `VITE_API_BASE` to that API base and restart Vite. |
| First backend startup takes longer than expected | Startup initialises the repository and trains the six in-process model entries before serving requests. Wait for Uvicorn to finish startup, then check `/api/health`. |
| Health reports `demo` or `sqlite-cache` instead of `supabase` | This is the intended fallback behavior. To use Supabase, run the SQL schema, set `SUPABASE_URL` plus `SUPABASE_SERVICE_ROLE_KEY`, execute `python -m app.seed`, and restart the API. |
| Health warns that Supabase is empty | Run `python -m app.seed` from `backend` after the schema is installed and the environment variables are present. |
| Seed command says credentials are missing | Confirm `backend/.env` exists and uses `SUPABASE_SERVICE_ROLE_KEY` or `SUPABASE_ANON_KEY` along with `SUPABASE_URL`; server-side writes require the service-role key under the supplied RLS policy. |
| An API request fails validation | Inspect the typed `422` response body. The Pydantic request models enforce required fields and reflectance limits for `/api/indices`. |
| A requested plot or table is unknown | Use `/api/plots` or `/api/dataset/export?table=plots` to obtain valid identifiers. Missing resources intentionally return `404`. |
